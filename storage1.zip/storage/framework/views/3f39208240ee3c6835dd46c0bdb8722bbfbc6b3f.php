

<?php $__env->startSection('content'); ?>
	<div class="container">

	
		<div class="row mb-4">
		<?php $__currentLoopData = $loads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $load): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-4">
				<div class="card">
					<div class="card-img-top embed-responsive embed-responsive-21by9">
						<img class="card-img-top embed-responsive-item" src="/images/<?php echo e($load->randomImage()); ?>" alt="image <?php echo e($load->randomImage()); ?>">
					</div>
					<div class="card-img-overlay">
						<h3 class="card-title">
						<?php $__currentLoopData = $load->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<span><?php echo e($category->name); ?></span>
						</h3>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
	                <div class="feature-wrap" style="margin-top: -2em; margin-bottom: -2em; z-index: 888888; position: relative;">
	                    <i class="<?php echo e($load->transportMode()); ?>"></i>  		                                            
	                </div>	

					<div class="card-body">
						<p class="pull-right">Updated <?php echo e($load->updated_at->diffForHumans()); ?></p>
						<h3 class="card-title"><?php echo e($load->name); ?></h3>
						<hr>
						<p class="card-text">
							<b>Description:</b> <?php echo e($load->size); ?> x <?php echo e($load->quantity); ?> items and <?php echo e($load->containers); ?> Container(s)
						</p>
						<p class="card-text">
							<b>From: </b> <?php echo e($load->pickup_city); ?> <?php echo e($load->pickup_country); ?>

						</p>
						<p class="card-text">
							<b>To: </b> <?php echo e($load->destination_city); ?> <?php echo e($load->destination_country); ?>

						</p> 
						<p class="card-text">
							<i class="fa fa-calendar fa-3x"> </i>
							<b>Preferred Pickup Date:</b> <?php echo e($load->pickup_date->format('D d M Y')); ?>

						</p>						
					</div>
					<div class="card-footer" style="position: relative; z-index: 999999">
						<a href="/loads/<?php echo e($load->slug); ?>">Read more</a>
					</div>

				</div>

			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		   <?php echo e($loads->links()); ?>


	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp2020apr\www\transpartaug20\resources\views/load/index.blade.php ENDPATH**/ ?>