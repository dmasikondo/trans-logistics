

<?php $__env->startSection('content'); ?>
	<div class="container">
		<h5>It seems this resource is no longer available to you!</h5>
	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp2020apr\www\transpartaug20\resources\views/errors/403.blade.php ENDPATH**/ ?>