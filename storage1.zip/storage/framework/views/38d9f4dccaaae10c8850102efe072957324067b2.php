
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
<!-- private visibility -->        	
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ownerOnly', $load)): ?>
					 <private-visibility-button :load="<?php echo e($load); ?>"></private-visibility-button>
	<?php endif; ?>

				<div class="card">
					<div class="card-img-top embed-responsive embed-responsive-21by9">
						<img class="card-img-top embed-responsive-item" src="/images/<?php echo e($load->randomImage()); ?>" alt="image <?php echo e($load->randomImage()); ?>">
					</div>
<!-- consignment category -->
					<div class="card-img-overlay">
						<h3 class="card-title">
						<?php $__currentLoopData = $load->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<kbd><?php echo e($category->name); ?></kbd>
						</h3>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<div class="row">
		                <div class="feature-wrap col-md-6" style="margin-top: -6em; z-index: 888888; position: relative;">
		                    <i class="<?php echo e($load->transportMode()); ?>"></i>

		                </div>	
		                <div class="col-md-5 text-right">

		                	<p>
		                		<small class="textmuted">Updated <?php echo e($load->updated_at->diffForHumans()); ?></small>	
		                	</p>
<!-- Edit and Delete links -->		                	

		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $load)): ?>
				     		<p>
			            		<span class="pull-left">			            			
			            			<a href="/loads/<?php echo e($load->slug); ?>/edit"><i class="fa fa-edit"> Edit</i></a>
			            		</span>		
			            		<delete-load :freight="<?php echo e($load); ?>"></delete-load>			     			
				     		</p>
		<?php endif; ?>	

		                </div>	

	    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $load)): ?>
	            		<distance-vehicletype :freight="<?php echo e($load); ?>"></distance-vehicletype>
	    <?php endif; ?>

					</div>

					<div class="card-body">
<!-- Consignemnt details -->						
						<h3 class="card-title"><?php echo e($load->name); ?></h3>
						<hr>
						<p class="card-text">
							<b>Description:</b> <?php echo e($load->size); ?> x <?php echo e($load->quantity); ?> items and <?php echo e($load->containers); ?> Container(s)
						</p>
						<p class="card-text">
							<b>Distance (km): </b> <?php echo e(is_null($load->distance)? 'Not Stated' : $load->distance); ?>

						</p>
						<p class="card-text">
							<b>Required Truck Type: </b> <?php echo e(is_null($load->vehicle_type)? 'Not Specified' : $load->vehicle_type); ?>

						</p> 
						<div class="row">
							<div class="col-md-6">
								<p class="card-text">
									<i class="fa fa-calendar fa-3x"> </i>
									<b>Preferred Pickup Date:</b> <?php echo e($load->pickup_date->format('D d M Y')); ?>

								</p>								
							</div>
							<div class="col-md-6">
								<p class="card-text">
									<i class="fa fa-road fa-3x"> </i>
									<b>Preferred Route:</b> <?php echo e(is_null($load->preferred_route)? 'Not Specified' : $load->preferred_route); ?>

								</p>										
							</div>
						</div>
						
					</div>
					<div class="card-footer" style="position: relative; z-index: 999999">
						<bid-component :load="<?php echo e($load); ?>"></bid-component>
					</div>

				</div>
<!-- public-visibility -->
	    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('superconfidential', $load)): ?>		
					<public-visibility-button :load="<?php echo e($load); ?>"></public-visibility-button>	
		<?php endif; ?>	

				<div class="row justify-center">
					<div class="col-md-7 offset-md-1">
						<h3><kbd>More Details</kbd></h3>

						<?php echo nl2br($load->requirements); ?>					
					</div>
				</div>


<!-- location --> <div class="row justify-center about wow fadeInDown">
				 	<div class="col-md-5 offset-md-1">
				 		<h5>
				 			<span class="fa fa-map-marker fa-3x text-primary"> </span>
				 			Pick up location
				 		</h5>
				 		<p>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('confidential', $load)): ?>					 			
				 			<span class="fa fa-lg fa-road"> </span> <?php echo e($load->pickup_street); ?> <small class="text-muted">(Not Public)</small><br>
<?php endif; ?>
				 			<span class="fa fa-lg fa-building"> </span> <?php echo e($load->pickup_city); ?><br>
				 			<span class="fa fa-lg fa-flag"> </span> <?php echo e($load->pickup_country); ?><br>
				 			<span class="fa fa-lg fa-calendar"> </span>	
							Ready to Pick up on <br>
							<?php echo e($load->pickup_date->format('l d F Y')); ?>

				 		</p>
				 	</div>
				 	<div class="col-md-6">
				 		<h5>
							<span class="fa fa-map-marker text-danger fa-3x"> </span>
				 			Destination Location
				 		</h5>
				 		<p>
<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('confidential', $load)): ?>	
				 			<span class=" fa fa-lg fa-road"> </span> <?php echo e($load->destination_street); ?> <small class="text-muted">(Not Public)</small><br>
<?php endif; ?>
				 			<span class=" fa fa-lg fa-building"> </span> <?php echo e($load->destination_city); ?><br>
				 			<span class=" fa fa-lg fa-flag"> </span> <?php echo e($load->destination_country); ?><br>
				 			<span class="fa fa-calendar fa-lg">   </span>	
							Expected to be delivered on <br>
							<?php echo e($load->destination_date->format('l d F Y')); ?>					 			
				 		</p>					 		
				 	</div>					 	

				 </div>	
				 <div class="row">
				 	<div class="col-md-6">
				 		<h3>
<!--Payment -->	 			<mark>Payment Offer</mark>
				 			<span class="fa fa-money fa-2x pull-right"></span>
				 		</h3>
						<ul class="list-group">
						  <li class="list-group-item list-group-item-success">Carriage Rate: - <?php echo e($load->carriage_rate); ?></li>
						  <li class="list-group-item list-group-item-info"><?php echo e($load->amount); ?></li>
						  <li class="list-group-item list-group-item-warning"><?php echo e($load->payment_option); ?></li>
						</ul>
				 	</div>
<!--Consignment Creator -->
 <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('superconfidential', $load)): ?>
					<div class="col-md-6">
		                <div class="feature-wrap">
		                    <i class="fa fa-user"></i>
		                    <h3>Consignment Creator <small class="text-muted">(Not Public)</small></h3>
		                    <h4>
		                    	<a href="/#"><?php echo e($load->nameOfCreator(Auth::user())? 'Me' : $load->user->organisation); ?></a> 
		                    </h4>
		                    <p><?php echo e($load->user->email); ?></p>
		            <?php $__currentLoopData = $load->user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                    <span class="pull-right label label-success"><?php echo e($role->name); ?></span>
		          	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		                </div>						
					</div>
<?php endif; ?>
<!-- end of consignment creator -->				 	
				 </div>	

        </div>
<!-- end of Consignment listing -->

		<div class="col-md-3 offset-md-1">
<!-- Freight bids --->
			<h3>
				Consignment Bids
				<span class="badge badge-default"><?php echo e($load->bids->count()); ?></span>
			</h3>
			<?php $__currentLoopData = $load->bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="media mb-4">
					<span class="circle <?php echo e(App\Bid::randomColor()); ?> mr-2"><?php echo e(substr($bid->bidder->organisation,0,1)); ?></span>
					<div class="media-body">
						<a href="/bids/<?php echo e($bid->slug); ?>"><?php echo e($bid->bidder->organisation); ?></a> <br>
						<?php echo e($bid->city_location); ?>, <?php echo e($bid->country_location); ?> <br>
						<?php echo e($bid->trailer_type); ?>

						<small class="text-muted">Posted <?php echo e($bid->updated_at->diffForHumans()); ?></small> 						
					</div>
				</div>	

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Suggested vehicles -->
			<h3>
				Suggested Vehicles
				<span class="badge badge-default"><?php echo e($vehicles->count()); ?></span>
			</h3>
			<?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="media">
					<span class="circle"><?php echo e(substr($vehicle->user->organisation,0,1)); ?></span>
					<div class="media-body">
						<p>
							<?php echo e($vehicle->user->organisation); ?> <br>
							<?php echo e($vehicle->trailer_type); ?><br>
							<?php echo e($vehicle->city_from); ?> To <?php echo e($vehicle->city_to); ?><br>

							<small class="text-muted">Posted <?php echo e($vehicle->updated_at->diffForHumans()); ?></small> 
						</p>
					</div>
				</div>	

					


			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>


    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp2020apr\www\transpartaug20\resources\views/load/show.blade.php ENDPATH**/ ?>