
<?php $__env->startSection('content'); ?>
	<load-component :user="<?php echo e($load->user); ?>" :freight="<?php echo e($load); ?>" :edit-mode="true"></load-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp2020apr\www\transpartaug20\resources\views/load/edit.blade.php ENDPATH**/ ?>