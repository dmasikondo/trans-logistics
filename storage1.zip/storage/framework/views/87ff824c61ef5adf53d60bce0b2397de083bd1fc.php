

<?php $__env->startSection('content'); ?>
	<director-component :user="<?php echo e($user); ?>"></director-component>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp2020apr\www\transpartaug20\resources\views/registration/directors.blade.php ENDPATH**/ ?>