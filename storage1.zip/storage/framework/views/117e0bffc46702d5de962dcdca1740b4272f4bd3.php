<style>
html,body{
 /*background: url(<?php echo e(asset('storage/images')); ?>/city_night.jpg) no-repeat;
background-size: cover;
height: 100%;
}

.container{
height: 100%;
align-content: center;
}

*/
</style>
<?php $__env->startSection('content'); ?>

<user-registration-component></user-registration-component>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp2020apr\www\transpartaug20\resources\views/auth/register.blade.php ENDPATH**/ ?>