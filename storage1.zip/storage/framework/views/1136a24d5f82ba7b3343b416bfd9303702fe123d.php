<!doctype html>
<html>
<head>
<style>
body{background:#1F4D1D;
	color:#F7F7F7; padding: 1%;
}
</style>
<meta charset="utf-8">
<title>Mail From <?php echo e($name); ?> <?php echo e($email); ?></title>
</head>

<body>
	<p>Mail From <?php echo e($name); ?> <?php echo e($email); ?>

	<h3>Message</h3>
    <p><?php echo nl2br($content); ?></p>
    <p><small>Send from Contact Page</small>

</body>
</html><?php /**PATH C:\wamp2020apr\www\transpartaug20\resources\views/emails/send.blade.php ENDPATH**/ ?>