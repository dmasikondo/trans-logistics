

<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="card">    
            <div class="card-header">
                <h2 class="py-4">
                	Bid for: <?php echo e($bid->bidable->name); ?>

                	<small class="pull-right">
                		<?php echo e($bid->bidable->pickup_city); ?> To <?php echo e($bid->bidable->destination_city); ?>

                		<span class="fa-3x <?php echo e($bid->bidable->transportMode()); ?>"></span>
                	</small>
                	
                </h2>
                <div class="feature-wrap justify-content-center d-flex">
                    <i class="fa fa-gavel"></i>                          
                </div> 

                <div class="row">

	                <div class="col-md-9">
	                    <a href="/loads/<?php echo e($bid->bidable->slug); ?>" >  
	                        Back <i class="fa fa-chevron-left fa-2x text-success"></i>
	                    </a>                                        
	                </div>

					<div class="col-md-3 media mb-4 justify-content-right d-flex">
						<span class="circle <?php echo e(App\Bid::randomColor()); ?> mr-2"><?php echo e(substr($bid->bidder->organisation,0,1)); ?></span>
						<div class="media-body">
							<a href="/bids/<?php echo e($bid->slug); ?>"><?php echo e($bid->bidder->organisation); ?></a> <br>
							<small class="text-muted">Posted <?php echo e($bid->updated_at->diffForHumans()); ?></small> 						
						</div>
					</div>  

                </div>

            </div>  
          </div>
<!--Bid comparisaon --> 
				<ul class="list-group">
				  <li class="list-group-item">
					  	<b>Trailer Type</b> 
					  	<span class="pull-right"><?php echo e($bid->trailer_type); ?> 
					  		<b class="text-muted"> | required</b> 
					  		<?php echo e($bid->bidable->vehicle_type); ?>

					  	</span>	
					  	<span class="fa <?php echo e($bid->trailer_type === $bid->bidable->vehicle_type? 'text-success fa-check': 'text-danger fa-remove'); ?>"><span>			
				  </li>

				  <li class="list-group-item">
					  	<b>Vehicle Country Location</b> 
					  	<span class="pull-right"><?php echo e($bid->country_location); ?> 
					  		<b class="text-muted"> | required</b> 
					  		<?php echo e($bid->bidable->pickup_country); ?>

					  	</span>	
					  	<span class="fa <?php echo e($bid->country_location === $bid->bidable->pickup_country? 'text-success fa-check': 'text-danger fa-remove'); ?>"><span>			
				  </li>	

				  <li class="list-group-item">
					  	<b>Vehicle City Location</b> 
					  	<span class="pull-right"><?php echo e($bid->city_location); ?> 
					  		<b class="text-muted"> | required</b> 
					  		<?php echo e($bid->bidable->destination_city); ?>

					  		<kbd>Preferred Route: <?php echo e($bid->bidable->preferred_route); ?></kbd>
					  	</span>	
					  	<span class="fa <?php echo e($bid->city_location === $bid->bidable->destination_city? 'text-success fa-check': 'text-danger fa-remove'); ?>"><span>			
				  </li>		

				  <li class="list-group-item">
					  	<b>Vehicle Capacity (tonnes)</b> 
					  	<span class="pull-right"><?php echo e($bid->available_capacity); ?> 
					  		<b class="text-muted"> | required</b> 
					  		<?php echo e($bid->bidable->size); ?> x 
					  		<?php echo e($bid->bidable->quantity); ?>

					  		<?php echo e(is_null($bid->bidable->containers)? '0' : $bid->bidable->containers); ?>Container(s)
					  	</span>				
				  </li>					  		  

				  <li class="list-group-item">
					  	<b>Cost US$</b> 
					  	<span class="pull-right"><?php echo e($bid->price); ?> 
					  		<b class="text-muted"> | required</b> 
					  		<?php echo e($bid->bidable->carriage_rate); ?> 
					  		<?php echo e($bid->bidable->amount); ?>

					  		<kbd><?php echo e($bid->bidable->payment_option); ?></kbd>
					  	</span>				
				  </li>	
				</ul>


	<!--- Other Bidders -->
			<div class="card">
	         	<div class="card-body">
	         		<h4 style="margin-top: -2em;">Other Bidders</h4>
			<?php $__currentLoopData = $bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
					<a href="/bids/<?php echo e($bid->slug); ?>" title=<?php echo e($bid->bidder->organisation); ?>>
						<span class="float-left circle <?php echo e(App\Bid::randomColor()); ?> mr-2"><?php echo e(substr($bid->bidder->organisation,0,1)); ?></span>	
					</a>		
								
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	         		
	         	</div>
	         </div>						         
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp2020apr\www\transpartaug20\resources\views/bid/show.blade.php ENDPATH**/ ?>