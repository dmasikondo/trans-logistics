<?php echo e($slot); ?>

<?php /**PATH C:\wamp2020apr\www\transpartaug20\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>