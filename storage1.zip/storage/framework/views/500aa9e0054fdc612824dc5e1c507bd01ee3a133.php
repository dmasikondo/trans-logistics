

<?php $__env->startSection('content'); ?>
	<div class="container">	
		<vehicle-private-visibility :vehicle="<?php echo e($vehicle); ?>"></vehicle-private-visibility>	
		<div class="card">			
			<div class="card-header">
				<div class="pull-right">
					<a href="/vehicles/<?php echo e($vehicle->slug); ?>/edit"><i class="fa fa-edit"></i> Edit</a>
					<delete-vehicle :vehicle="<?php echo e($vehicle); ?>"></delete-vehicle>					
				</div>				
				<h3><?php echo e($vehicle->trailer_type); ?></h3>
				<p><?php echo e($vehicle->capacity); ?></p>
				<span class="text-center"><?php echo e($vehicle->available_date); ?></span>

			</div>			
			<div class="card-body">
				<div class="row">
					<div class="col-md-6">
						<h4 class="card-title">From</h4>
						<p><?php echo e($vehicle->city_from); ?></p>
						<p><?php echo e($vehicle->country_from); ?></p>

					</div>
					<div class="col-md-6">
						<h4 class="card-title">Destination</h4>
						<p><?php echo e($vehicle->city_to); ?></p>
						<p><?php echo e($vehicle->country_to); ?></p>						
					</div>
					<p><?php echo e($vehicle->more_details); ?></p>
				</div>				
			</div>
		</div>
			
			<vehicle-public-visibility :vehicle="<?php echo e($vehicle); ?>"></vehicle-public-visibility>

	</div>
	
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp2020apr\www\transpartaug20\resources\views/vehicle/show.blade.php ENDPATH**/ ?>