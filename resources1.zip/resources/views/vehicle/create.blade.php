@extends('layouts.app')

@section('content')
	<vehicle-component :edit-mode="false"></vehicle-component>
@endsection