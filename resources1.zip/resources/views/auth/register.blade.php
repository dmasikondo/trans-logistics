@extends('layouts.app')
<style>
html,body{
 /*background: url({{asset('storage/images')}}/city_night.jpg) no-repeat;
background-size: cover;
height: 100%;
}

.container{
height: 100%;
align-content: center;
}

*/
</style>
@section('content')

<user-registration-component></user-registration-component>

@endsection
