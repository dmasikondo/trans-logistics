@extends('layouts.app')

@section('content')
	<buslocation-component :user="{{$user}}"></buslocation-component>
@endsection