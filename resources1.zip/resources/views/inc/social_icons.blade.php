<li><a href="https://twitter.com/TranspartnerLog"><i class="fa fa-twitter"></i></a></li>
<li><a href="https://www.facebook.com/transpartnerlogisticsZim"><i class="fa fa-facebook"></i></a></li>
<li><a href="https://www.linkedin.com/company/transpartner-logistics-company?trk=biz-companies-cym"><i class="fa fa-linkedin"></i></a></li>