<script>
$('#goods').select2({
placeholder: 'Choose your Freight Category',
 tags: true,
allowClear:true
//goods:true
});
$('#countryfrom').select2({
placeholder: 'Pickup Country',
allowClear:true
});
$('#countryto').select2({
placeholder: 'Develivery Country',
allowClear:true
});
$('#payoption').select2({
placeholder: 'Select Payment Option',
allowClear:true
//goods:true
});
$('#roleList').select2({
placeholder: 'Choose Role',
allowClear:true
});
$('#trailer').select2({
placeholder: 'Choose Role',
allowClear:true
});

</script>