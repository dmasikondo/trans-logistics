@extends('layouts.app')

@section('content')
	<div class="container">
		<h5>It seems this resource is no longer available to you!</h5>
	</div>
	
@endsection