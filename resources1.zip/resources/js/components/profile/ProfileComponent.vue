<template>
    <div>

    <div>
         <h6 v-if="errors">
            <span class="text-danger"><strong>{{message}}</strong></span>
        </h6> 
        <form @submit.prevent="addFile" enctype="multipart/form-data">
            <input type="file" class="form-control" @change.prevent="onFileChange" id="video" :class="{'is-invalid': errors.hasError('file')}"  ref="fileInput">
             <span v-if="errors.hasError('country')" class="invalid-feedback" role="alert">
                <strong>{{errors.get('country')}}</strong>
            </span>

            <button type="submit" class="form-control btn btn-outline-primary btn-lg">
                Upload
                <i v-if="loading" class="fa fa-spinner fa-pulse"></i>
            </button>
        </form>
        <a href=""@click.prevent=deleteProfile()>
            <span class="fa fa-trash text-danger"></span> Delete
            <i v-if="loading" class="fa fa-spinner fa-pulse"></i>
        </a>
    </div>    
</div>

    
</template>
<script>
   class Errors{
        constructor(){
            this.errors = {};
        }
        get(field){
            if(this.errors[field]){
               return this.errors[field][0];
            }
        }
        hasError(field)
        {
             if(this.errors[field]){
              return true;
            } 
            else{
                return false;
            } 
        }
        clear(field){
           delete this.errors[field];
        }

        record(errors){
            this.errors = errors;
        }

    }
    export default{
        data()
        {
            return{
                file: '',
                errors: new Errors(),
                message: '',
                loading: false,
            }
        },
        props: {
            user: {
                type: Object,
              required: true
            },
        },

        methods:{
              onFileChange(){
               // this.file = document.getElementById('video').files[0];
                this.file = document.getElementById('video').files[0];
                 
              },

              addFile(){  
                    var formData = new FormData();
                    formData.append('video', this.file);                                               
                axios.post('/profiles', formData,{
                    /*  headers: {
                        'Content-type': 'multipart/form-data'
                    },*/
                }).then((response) =>{
                    this.message = '';
                    this.errors = new Errors();
                }).catch((e) =>{
                    this.errors.record(e.response.data.errors);
                    this.message = e.response.data.message + ' File not uploaded!';                    
                }).finally(() => (this.loading = false)); // set loading to false when request finish
              },
                 deleteProfile(){
                    this.loading = true, //the loading begin
                    Swal.fire({
                    title: "Are you sure?",
                    text: "Once Deleted, you will not be able to recover this document -- ",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonText:'Yes, delete it!',
                    cancelButtonText:'No, keep it',
                    }).then((willDelete) => {                        
                        if (willDelete.value) {                    
                             axios.delete('/profile/'+ this.user.slug, {
                            }).then((response) =>{                                                    
                            Swal.fire('Deleted!',
                            'Your consignment was successfully deleted',
                            'success'
                            ); 
                           // window.location.href='/loads/create';                                
                        }).catch((e)=>{
                            this.errors.record(e.response.data.errors);
                            this.message = e.response.data.message;
                            Swal.fire("Failure! "+ this.message, {
                            icon: "error",
                        });                        
                    }).finally(() => (this.loading = false)); // set loading to false when request finish;
                        } 
                        else if(willDelete.dismiss === Swal.DismissReason.cancel) {
                            Swal.fire('Cancelled',
                                        'Your document is safe',
                                        'error'
                            )
                        }
                    }).finally(() => (this.loading = false)); // set loading to false when request finish;
                 },         

        },
        mounted(){
    
        }        

    }   
</script>