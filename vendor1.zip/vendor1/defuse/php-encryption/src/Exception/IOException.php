<?php

namespace Defuse\Crypto\Exception;

class IOException extends \Defuse\Crypto\Exception\CryptoException
{
}
