<?php

namespace Defuse\Crypto\Exception;

class WrongKeyOrModifiedCiphertextException extends \Defuse\Crypto\Exception\CryptoException
{
}
